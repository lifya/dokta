

    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo base_url();?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>
  <!-- Footer -->
    <footer class="footer bg-light">
      <div class="container">
          <div class=" text-center">
            <p class="text-muted small mb-4 mb-lg-0">&copy; Dokumentasi TA 2018. All Rights Reserved.</p>
          </div>
      </div>
    </footer>

</html>