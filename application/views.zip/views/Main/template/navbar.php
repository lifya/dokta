<!-- Navigation -->
    <nav class="navbar navbar-light bg-light static-top bg-navbar">
      <div class="container-fluid">
        <a class="navbar-brand font-style" href="<?= base_url('index.php/cMain') ?>"><strong>DOKTA</strong></a>
        <ul class="nav justify-content-end">
          <li class="nav-item">
            <a class="nav-link font-style-menu" href="<?= base_url('index.php/cMain') ?>"><strong>Home</strong></a>
          </li>
          <li class="nav-item">
            <a class="nav-link font-style-menu" href="<?= base_url('index.php/cMain#about') ?>"><strong>About</strong></a>
          </li>
          <li class="nav-item">
            <a class="nav-link font-style-menu" href="<?= base_url('index.php/cMain#konsentrasi') ?>"><strong>Bidang Ilmu</strong></a>
          </li>
        </ul>
      </div>
    </nav>