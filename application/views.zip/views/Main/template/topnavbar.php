    <!-- Navigation -->
    <nav class="navbar navbar-light static-top padding-0 bg-navbar-top">
      <div class="container-fluid container-custom"> 
        <ul class="nav justify-content-start">
          <li class="nav-item">
            <i class="fa fa-envelope icon-custom"> bluecloning@gmail.com </i>
          </li>
          <li>
            <i class="fa fa-phone icon-custom"> 021-89765423 </i>
          </li>
        </ul>
        <ul class="nav justify-content-end">
          <li class="nav-item">
            <!-- <button class="btn btn-navbar btn-custom"><b>Publikasikan Tugas Akhir Kamu</b></button> -->
            <a href="<?php echo base_url('index.php/cLogin') ?>" class="btn btn-navbar btn-custom"><b>Publikasikan Tugas Akhir Kamu</b></a> 
          </li>
        </ul>
      </div>
    </nav>

    