<?php
defined('BASEPATH') OR exit('No direct script access allowed');


/**
* 
*/
class CSignup extends MY_Controller
{
	
	function __construct(argument)
	{
		# code...
	}
}